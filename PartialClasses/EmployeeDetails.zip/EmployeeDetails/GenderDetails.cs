namespace EmployeeDetails
{
    public enum GenderDetails
    {
        Select, Male, Female, Transgender
    }
}