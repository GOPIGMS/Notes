namespace StudentDetails
{
    public enum GenderDetails
    {
        Select, Male, Femal, TransGender
    }
}