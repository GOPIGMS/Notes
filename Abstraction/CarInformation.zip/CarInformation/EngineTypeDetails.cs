namespace CarInformation
{
    public enum EngineTypeDetails
    {
        //setting enum properties
        Select, Petrol, diesel, cng
    }
}