namespace CarInformation
{
    public enum CarTypeDetails
    {
        Select, HatchBack, Sedan, suv
    }
}