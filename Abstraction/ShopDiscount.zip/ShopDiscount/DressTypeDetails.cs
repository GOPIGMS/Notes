namespace ShopDiscount
{
    public enum DressTypeDetails
    {
        Select, LadiesWear, MensWear, ChildrensWear
    }
}