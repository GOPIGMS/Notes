﻿using System;

namespace MathsLib;

class Program{
    public static void Main(string[] args)
    {
        //library class
    }
}